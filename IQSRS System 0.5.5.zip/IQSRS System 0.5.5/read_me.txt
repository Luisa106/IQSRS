1.修正了读取部分，现在yf上获取的数据会储存到./stock/文件夹下
2.修改lstm部分，增加设置参数的函数set_parameter()